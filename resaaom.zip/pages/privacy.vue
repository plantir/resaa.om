<style lang="scss" scoped>
section {
  max-width: 900px;
  margin: auto;
  margin-top: 120px;
  margin-bottom: 110px;
  font-size: 18px;
  line-height: 32px;
  direction: ltr;
}
</style>
<template>
  <section>
    <h1>Privacy policy</h1>
    <p>&nbsp;</p>
    <h4>What information do we collect?</h4>
    <p>
      - The phone numbers you enter in "Blocked Numbers" and "Allowed Numbers" pages, or when you share a contact's phone number with Resa app.
      <br />- The voice you record and the text you enter as replies in Medical Test page.
      <br />- Some information about your iPhone device such as iOS version, iPhone model, your country and language set in your phone, and also session timing of your activity with the app.
    </p>
    <h4>What do we use your information for?</h4>
    <p>
      Any information we collect from you and store, may be used for the following reasons:
      <br />- So that you can have a better application usage experience, by enabling you login in in any other iPhone device you want with your current profile information.
      <br />- Collecting your iPhone device information would help us to better serve you and address any problems you would have when using our app.
    </p>
    <h4>Advertisement in Application</h4>
    <p>We don't use any information from you nor have we used any advertisement SDKs or services in our app for advertisement purposes.</p>
    <h4>Security Of Data</h4>
    <p>The security of your information is important to us. Although we cannot guarantee absolute and 100% security, but we try our best to secure and protect your information with industry-level technologies and tools.&nbsp;</p>
    <h4>Contact Us</h4>
    <p>
      In the event of having any questions or concerns regarding our privacy policy, please contact us:
      <br />resaa.om@yahoo.com
    </p>
  </section>
</template>
<script lang="ts">
import Vue from 'vue'
export default Vue.extend({
  layout: 'landing'
})
</script>