import Vue from 'vue'
import iconLoader from '@/components/icons/loader.vue'
Vue.component('iconLoader', iconLoader)
