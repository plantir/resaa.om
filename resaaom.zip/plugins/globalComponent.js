import Vue from 'vue'
import vueCustomScrollbar from 'vue-custom-scrollbar'
Vue.component('vueCustomScrollbar', vueCustomScrollbar)
