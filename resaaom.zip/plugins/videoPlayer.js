import Vue from 'vue'
import VueVideoPlayer from 'vue-video-player/dist/ssr'
Vue.use(VueVideoPlayer)
